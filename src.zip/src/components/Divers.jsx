function Direct() {
    return (
        <div>
            <p>test</p>
        </div>
    )
}

export default Direct