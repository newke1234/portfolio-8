import React, { useState } from 'react'
import cardsData from '../datas/cards.json'
// import booki from '../assets/covers/booki_cover.jpg'
import '../styles/cards.scss'

function Cards() {
    const [jsonData] = useState(cardsData)
    
    const getImagePath = (path) => {
      try {
        if (path.startsWith('./assets/')) {
          // Remplace './assets/' par '../assets/' pour correspondre à la structure du dossier
          const correctedPath = path.replace('./assets/', '../assets/');
          return require(`${correctedPath}`);
      }
          return path; // Retourne le chemin tel quel si c'est une URL
      } catch (err) {
          console.error("Failed to load image:", err);
          return null; // Gestion d'erreur si l'image ne peut pas être chargée
      }
  };

    return (
        <ul className="cards">
          {jsonData.map((card, id) => (
            <li key={id} className="cards__projects">
                {card.type === 'project' && (
                <img
                  // className="cards__project__image"
                  src={getImagePath(card.cover)}
                  alt={card.title}
                />
                )}
                {card.type === 'letter' && (
                <p className="cards__letter">{card.title}</p>
                )}
                {/* <div className="cards__project__gradient"></div> */}
                {/* <div className="cards__project__title">{card.title}</div> */}
            </li>
          ))}
          {/* Si aucun projet n'a été trouvé pour un ID donné, rediriger directement vers la page 404 */}
          {/* {!isProjectIdValid && <Link to="/404" style={{ display: 'none' }} />} */}
        </ul>
      )
}

export default Cards