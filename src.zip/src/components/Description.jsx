import React, { useState } from 'react'
import cardsData from '../datas/cards.json'

function Description(project) {
    const [jsonData] = useState(cardsData)

    return (
        <div>

            <div className="description">
            {jsonData.map((card, id) => (
                <li key={id} className="cards__projects">
                    {card.type === 'project' && (
                        <p>test</p>
                    // <img
                    // src={getImagePath(card.picture)}
                    // alt={card.title}
                    // />
                    )}
                    
                 
                </li>
            ))}
            {/* Si aucun projet n'a été trouvé pour un ID donné, rediriger directement vers la page 404 */}
            {/* {!isProjectIdValid && <Link to="/404" style={{ display: 'none' }} />} */}
           
            </div>
        </div>
    )
}

export default Description